
</head>

<div class="row m-4 ">
    <div class="col-sm-4 logo"><img src="../img/joblo.png" style="hight:80px;width:150px"></div>


    <div class="col-sm-8 menu ">
        <nav class="navbar navbar-expand-lg navbar-light ">
            
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"  aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item active">
                  <a class="nav-link" href="admindasboard.php">Dashboard<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item dropdown ">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Add diteles
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="addcategory.php">add catagary</a>
                            <a class="dropdown-item" href="addjob.php">new job</a>
                            
                          </div>
                        </li>
                        <li class="nav-item dropdown ">
                          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            management
                          </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="jobmgnt.php">JOB MGNT</a>
                            <a class="dropdown-item" href="#.php">new job</a>
                            
                          </div>
                        </li>
                <li class="nav-item">
                  <a class="nav-link " href="changepassword.php">CHANGE PASSWORD</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="logout.php">Log Out</a>
                  </li>
              </ul>
            </div>
          </nav>


    </div>
    </div>
    </div>
    </div>
    
</div>


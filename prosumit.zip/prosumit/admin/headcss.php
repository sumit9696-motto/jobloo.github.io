.trusted{
    height: 100px; 
    width: 350px;
    color: white;
    text-align: center;
    font-size: 30px;
    padding:20px;
    transform: translateX(-150px );
    margin-top: 40px;
    border: 10px solid rgba(255, 255, 255, .6);
    
  }
.clogo{color: red;
      font-size: 40px;
  }    
.line{
      box-shadow: 0px 0px 5px 1px white inset;
  }

.input-group.md-form.form-sm.form-1 input{
border: 1px solid #bdbdbd;
border-top-right-radius: 0.25rem;
border-bottom-right-radius: 0.25rem;
}
.input-group.md-form.form-sm.form-2 input {
border: 1px solid #bdbdbd;
border-top-left-radius: 0.25rem;
border-bottom-left-radius: 0.25rem;
}
.input-group.md-form.form-sm.form-2 input.red-border {
border: 1px solid #ef9a9a;
}
.input-group.md-form.form-sm.form-2 input.lime-border {
border: 1px solid #cddc39;
}
.input-group.md-form.form-sm.form-2 input.amber-border {
border: 1px solid #ffca28;
}
hr{

background-color: white;
}

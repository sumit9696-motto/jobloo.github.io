







<!-- start footer  -->
<style>
    hr{
  
  background-color: white;
}
</style>







<!-- start footer  -->

    
<div class="row">

<div class="col-sm-12 text-center" style="height: 50px; background-color: black; font-size: 18px;line-height: 50px; ">
  
  <span  style="height: 50px; background-color: black; color: white;"> | &copy; 2020</span>
  <span style="color: orange;"> ||golo jolo pvt.ltd || </span>
  <span  style="height: 50px; background-color: black; color: white;"> devvelop byr raj mishra | </span>
</div>
</div>
    
    
    
    <!-- end footer -->